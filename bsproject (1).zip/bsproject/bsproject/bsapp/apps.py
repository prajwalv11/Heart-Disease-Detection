from django.apps import AppConfig


class BsappConfig(AppConfig):
    name = 'bsapp'
