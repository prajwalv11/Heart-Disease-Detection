import pandas as pd
data=pd.read_csv(r'E:\heart.csv')
data.head()
print(data.head(10))